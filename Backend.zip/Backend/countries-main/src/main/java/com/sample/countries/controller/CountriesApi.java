package com.sample.countries.controller;

public interface CountriesApi {
}
