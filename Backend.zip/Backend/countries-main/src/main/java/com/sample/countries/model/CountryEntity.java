package com.sample.countries.model;

import lombok.*;


@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class CountryEntity {
    private Name name;
    private long population;
    private String capital;

    public String getCountryDetailsByName() {
        return "details";
    }
}


