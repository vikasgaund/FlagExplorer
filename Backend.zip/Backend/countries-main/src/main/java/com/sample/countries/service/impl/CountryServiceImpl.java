package com.sample.countries.service.impl;

import com.sample.countries.exception.ServiceException;
import com.sample.countries.model.CountryEntity;
import com.sample.countries.service.CountryService;
import com.sample.countries.service.ExternalCountryApiService;
import lombok.extern.log4j.Log4j2;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@Log4j2
public class CountryServiceImpl implements CountryService {

    private final ExternalCountryApiService apiService;

    public CountryServiceImpl(ExternalCountryApiService apiService) {
        this.apiService = apiService;
    }

    @Override
    public List<CountryEntity> getCountriesNoFilter() {
        log.debug("Fetch countries data from api with no filter");
        return apiService.getCountries();
    }



    @Cacheable(value = "getCountryDetailsByName", key = "#name")
    public CountryEntity getCountryDetailsByName(String name) {
        log.debug("Fetching countries data from API");
        List<CountryEntity> countryList = apiService.getCountries();
        Set<String> asianCountriesCca3;
        CountryEntity theCountry = null;
        asianCountriesCca3 = countryList.stream()
                .filter(country -> country.getCountryDetailsByName().equalsIgnoreCase(name))
                .map(CountryEntity::getCountryDetailsByName)
                .collect(Collectors.toSet());

        if (theCountry == null) {
            throw new ServiceException("Failed to fetch Country details.");
        }
        return theCountry;
    }

}
