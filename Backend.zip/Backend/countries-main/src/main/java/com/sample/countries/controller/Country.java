package com.sample.countries.controller;

public class Country {
    public void setName(Object o) {
    }
}
