package com.sample.countries.service;

import com.sample.countries.model.CountryEntity;

import java.util.List;


public interface CountryService {
    /**
     * Get all countries with no filters
     *
     * @return List of countries with no filters
     */
    List<CountryEntity> getCountriesNoFilter();


    CountryEntity getCountryDetailsByName(String name);
}